############################################################################################
# class definition for SSMParamStore.
# get and put method is implemented for reuse.
############################################################################################

import boto3
from botocore.exceptions import ClientError
import datetime

conf = None

class SSMParamStore(object):
    """
    Provide a dictionary-like interface to access AWS SSM Parameter Store
    """
    def __init__(self, prefix=None, ssm_client=None, ttl=None):
        self._prefix = (prefix or "").rstrip("/") + "/"
        self._client = ssm_client or boto3.client('ssm')
        self._keys = None
        self._substores = {}
        self._ttl = ttl
        self.errormsg = None

    def get(self, name, default=None):
        assert name, 'Name can not be empty!'
        if self._keys is None:
            self.refresh()

        abs_key = "%s%s" % (self._prefix, name)
        if name not in self._keys:
            self.errormsg = "get error: Key not exist!"
            return default
        elif self._keys[name]['type'] == 'prefix':
            if abs_key not in self._substores:
                store = self.__class__(prefix=abs_key, ssm_client=self._client, ttl=self._ttl)
                self._substores[abs_key] = store

            return self._substores[abs_key]
        else:
            return self._get_value(name, abs_key)

    def put(self, key, value):
        assert key, 'Key can not be empty!'

        abs_key = "%s%s" % (self._prefix, key)
        try:
            response = self._client.put_parameter(
                Name=abs_key,
                Value=value,
                Overwrite=True,
                Type='String'
            )

            if self._keys is None:
                return response['Version']
            elif key not in self._keys:
                self.refresh()
                return response['Version']
            else:
                if self._keys[key]['type'] == 'parameter':
                    entry = self._keys[key]
                    entry['value'] = value

                    if self._ttl:
                        entry['expire'] = datetime.datetime.now() + datetime.timedelta(seconds=self._ttl)

                return response['Version']
        except ClientError as e:
            self.errormsg = "put error: %s" % e
            return 0

    def put_secure(self, key, value, kmsKeyId=None):
        assert key, 'Key can not be empty!'

        abs_key = "%s%s" % (self._prefix, key)
        try:
            if kmsKeyId is None:
                response = self._client.put_parameter(
                    Name=abs_key,
                    Value=value,
                    Overwrite=True,
                    Type='SecureString'
                )
            else:
                response = self._client.put_parameter(
                    Name=abs_key,
                    Value=value,
                    KeyId=kmsKeyId,
                    Overwrite=True,
                    Type='SecureString'
                )


            if self._keys is None:
                return response['Version']
            elif key not in self._keys:
                self.refresh()
                return response['Version']
            else:
                if self._keys[key]['type'] == 'parameter':
                    entry = self._keys[key]
                    entry['value'] = value

                    if self._ttl:
                        entry['expire'] = datetime.datetime.now() + datetime.timedelta(seconds=self._ttl)

                return response['Version']
        except ClientError as e:
            self.errormsg = "put_secure error: %s" % e
            return 0

    def delete(self, name):
        assert name, 'Name can not be empty!'
        if self._keys is None:
            self.refresh()

        abs_key = "%s%s" % (self._prefix, name)
        if name not in self._keys:
            self.errormsg = "delete error: %s not exist!" % abs_key
            return None
        elif self._keys[name]['type'] == 'prefix':
            self.errormsg = "delete error: %s is not a parameter!" % abs_key
            return None
        else:
            resp = self._client.delete_parameter(Name=abs_key)
            self._keys.pop(name,None)
            return resp

    def refresh(self):
        self._keys = {}
        self._substores = {}

        end_of_rec = False
        nextToken = ''
        while not end_of_rec:
            if not nextToken:
                responses = self._client.describe_parameters(
                    ParameterFilters=[
                        dict(Key="Path", Option="Recursive", Values=[self._prefix])
                    ]
                )
            else:
                responses = self._client.describe_parameters(
                    NextToken=nextToken,
                    ParameterFilters=[
                        dict(Key="Path", Option="Recursive", Values=[self._prefix])
                    ]
                )

            try:
                nextToken = responses[u'NextToken']
            except:
                end_of_rec = True

            for p in responses[u'Parameters']:
                paths = p['Name'][len(self._prefix)-1:].lstrip("/").split('/')
                name = paths[0]

                # this is a prefix
                if len(paths) > 1:
                    self._keys[name] = {'type': 'prefix'}
                else:
                    self._keys[name] = {'type': 'parameter', 'expire': None}

    def keys(self):
        if self._keys is None:
            self.refresh()

        return self._keys.keys()

    def noHandler(self):
        if self._client is None:
            return True
        else:
            return False
            
    def _get_value(self, name, abs_key):
        entry = self._keys[name]

        # simple ttl
        if self._ttl == False or (entry['expire'] and entry['expire'] <= datetime.datetime.now()):
            entry.pop('value', None)

        if 'value' not in entry:
            parameter = self._client.get_parameter(Name=abs_key, WithDecryption=True)['Parameter']
            value = parameter['Value']
            if parameter['Type'] == 'StringList':
                value = value.split(",")

            entry['value'] = value

            if self._ttl:
                entry['expire'] = datetime.datetime.now() + datetime.timedelta(seconds=self._ttl)
            else:
                entry['expire'] = None

        return entry['value']

    def __contains__(self, name):
        try:
            self.get(name)
            return True
        except:
            return False

    def __getitem__(self, name):
        return self.get(name)

    def __setitem__(self, key, value):
        return self.put(key,value)

    def __delitem__(self, name):
        return self.delete(name)

    def __repr__(self):
        return 'ParameterStore[%s]' % self._prefix
