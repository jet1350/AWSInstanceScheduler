############################################################################################
# Instance Scheduler Helper
# Put the custom configuration parameter got from CloudFormation to SSM parameter store.
# implemented by calling SSMParamStore.
############################################################################################

import os, json, traceback, boto3
from botocore.vendored import requests

#import ssm_paramstore file for accessing SSM ParameterStore
import ssm_paramstore
from ssm_paramstore import SSMParamStore

# environment parameter for configuration table
ENV_CONFIG = "CONFIG_TABLE"
ENV_STATE = "STATE_TABLE"
ENV_ACCOUNT = "ACCOUNT"
ENV_STACK = "STACK_NAME"
ENV_TAG_NAME = "TAG_NAME"
ENV_TRACE = "TRACE"
ENV_USER_AGENT = "USER_AGENT"
ENV_BOTO_RETRIES = "BOTO_RETRY"
ENV_BOTO_RETRY_LOGGING = "BOTO_RETRY_LOGGING"
ENV_METRICS_URL = "METRICS_URL"
ENV_SOLUTION_ID = "SOLUTION_ID"
ENV_SEND_METRICS = "SEND_METRICS"
ENV_LOG_GROUP = "LOG_GROUP"
ENV_ISSUES_TOPIC_ARN = "ISSUES_TOPIC_ARN"

def lambda_handler(event, context):
    # starting to process event
    print("InstanceSchedulerHelper Starting...")
    #print("Received event is {}".format(json.dumps(event, indent=3)))

    result = {
        "Status": 'SUCCESS',
        "Data": {},
        "Reason": "",
        "StackId": event.get("StackId"),
        "RequestId": event.get("RequestId"),
        "LogicalResourceId": event.get("LogicalResourceId"),
        "PhysicalResourceId": context.log_stream_name
    }

    customRes = event.get("ResourceProperties")
    if event.get("RequestType") == 'Create':
        if customRes.get("customAction") == 'putEnvConfig':
            try:
                #set parameterstore path prefix and get the handler to put parameter
                ssmPrefix = customRes.get("destPathPrefix")
                print("Create request. Path Prefix in SSM Parameter Store is {}".format(ssmPrefix))
                ssm_paramstore.conf = SSMParamStore(prefix=ssmPrefix)

                configItem = customRes.get('configItem')
                print("Received config item is {}".format(json.dumps(configItem, indent=3)))
                # put CONFIG_TABLE
                ver = ssm_paramstore.conf.put(ENV_CONFIG, configItem.get(ENV_CONFIG))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_CONFIG}
                    result["Status"] = 'FAILED'
                # put STATE_TABLE
                ver = ssm_paramstore.conf.put(ENV_STATE, configItem.get(ENV_STATE))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_STATE}
                    result["Status"] = 'FAILED'
                # put ACCOUNT
                ver = ssm_paramstore.conf.put(ENV_ACCOUNT, configItem.get(ENV_ACCOUNT))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_ACCOUNT}
                    result["Status"] = 'FAILED'
                # put STACK_NAME
                ver = ssm_paramstore.conf.put(ENV_STACK, configItem.get(ENV_STACK))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_STACK}
                    result["Status"] = 'FAILED'
                # put TAG_NAME
                ver = ssm_paramstore.conf.put(ENV_TAG_NAME, configItem.get(ENV_TAG_NAME))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_TAG_NAME}
                    result["Status"] = 'FAILED'
                # put TRACE
                ver = ssm_paramstore.conf.put(ENV_TRACE, configItem.get(ENV_TRACE))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_TRACE}
                    result["Status"] = 'FAILED'
                # put USER_AGENT
                ver = ssm_paramstore.conf.put(ENV_USER_AGENT, configItem.get(ENV_USER_AGENT))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_USER_AGENT}
                    result["Status"] = 'FAILED'
                # put BOTO_RETRY
                ver = ssm_paramstore.conf.put(ENV_BOTO_RETRIES, configItem.get(ENV_BOTO_RETRIES))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_BOTO_RETRIES}
                    result["Status"] = 'FAILED'
                # put BOTO_RETRY_LOGGING
                ver = ssm_paramstore.conf.put(ENV_BOTO_RETRY_LOGGING, configItem.get(ENV_BOTO_RETRY_LOGGING))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_BOTO_RETRY_LOGGING}
                    result["Status"] = 'FAILED'
                # put METRICS_URL
                ver = ssm_paramstore.conf.put(ENV_METRICS_URL, configItem.get(ENV_METRICS_URL))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_METRICS_URL}
                    result["Status"] = 'FAILED'
                # put SOLUTION_ID
                ver = ssm_paramstore.conf.put(ENV_SOLUTION_ID, configItem.get(ENV_SOLUTION_ID))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_SOLUTION_ID}
                    result["Status"] = 'FAILED'
                # put SEND_METRICS
                ver = ssm_paramstore.conf.put(ENV_SEND_METRICS, configItem.get(ENV_SEND_METRICS))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_SEND_METRICS}
                    result["Status"] = 'FAILED'
                # put LOG_GROUP
                ver = ssm_paramstore.conf.put(ENV_LOG_GROUP, configItem.get(ENV_LOG_GROUP))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_LOG_GROUP}
                    result["Status"] = 'FAILED'
                # put ISSUES_TOPIC_ARN
                ver = ssm_paramstore.conf.put(ENV_ISSUES_TOPIC_ARN, configItem.get(ENV_ISSUES_TOPIC_ARN))
                if ver == 0:
                    result["Reason"] = ssm_paramstore.conf.errormsg
                    result["Data"] = {"KeyName": ENV_ISSUES_TOPIC_ARN}
                    result["Status"] = 'FAILED'

            except Exception as ex:
                print("Put config error: {}".format(str(ex)))
                traceback.print_exc()
                result["Reason"] = str(ex)
                result["Status"] = 'FAILED'
        else:
            print("Unsupported action for Create request: {}".format(customRes.get("customAction")))
            result["Status"] = 'SUCCESS'
            result["Reason"] = 'Nothing to do. Unsupported action: ' + customRes.get("customAction")

    elif event.get("RequestType") == 'Delete':
        customRes = event.get("ResourceProperties")
        #set parameterstore path prefix and get the handler to delete parameter
        ssmPrefix = customRes.get("destPathPrefix")
        print("Delete Rquest. Path Prefix in SSM Parameter Store is {}".format(ssmPrefix))
        ssm_paramstore.conf = SSMParamStore(prefix=ssmPrefix)
        if ssm_paramstore.conf.noHandler():
            print("Exception error: ssm initialize failed.")
            result["Status"] = 'FAILED'
            result["Reason"] = 'Exception error: ssm initialize failed.'
        else:
            configItem = customRes.get('configItem')
            print("Received config item is {}".format(configItem))
            for name in configItem.keys():
                resp = ssm_paramstore.conf.delete(name)
                if resp:
                    print("config item <{}> deleted.".format(name))
                else:
                    print("config item <{}> not deleted. reason is {}".format(name,ssm_paramstore.conf.errormsg))

    elif  event.get("RequestType") == 'Update':
        try:
            #set parameterstore path prefix and get the handler to put parameter
            ssmPrefix = customRes.get("destPathPrefix")
            print("Update request. Path Prefix in SSM Parameter Store is {}".format(ssmPrefix))
            ssm_paramstore.conf = SSMParamStore(prefix=ssmPrefix)

            configItem = customRes.get('configItem')
            print("Received config item is {}".format(json.dumps(configItem, indent=3)))
            # put CONFIG_TABLE if updated
            if ssm_paramstore.conf.get(ENV_CONFIG) != configItem.get(ENV_CONFIG):
                ver = ssm_paramstore.conf.put(ENV_CONFIG, configItem.get(ENV_CONFIG))
                if ver == 0:
                    print("{} update error: {}".format(ENV_CONFIG,ssm_paramstore.conf.errormsg))
            # put STATE_TABLE if updated
            if ssm_paramstore.conf.get(ENV_STATE) != configItem.get(ENV_STATE):
                ver = ssm_paramstore.conf.put(ENV_STATE, configItem.get(ENV_STATE))
                if ver == 0:
                    print("{} update error: {}".format(ENV_STATE,ssm_paramstore.conf.errormsg))
            # put ACCOUNT if updated
            if ssm_paramstore.conf.get(ENV_ACCOUNT) != configItem.get(ENV_ACCOUNT):
                ver = ssm_paramstore.conf.put(ENV_ACCOUNT, configItem.get(ENV_ACCOUNT))
                if ver == 0:
                    print("{} update error: {}".format(ENV_ACCOUNT,ssm_paramstore.conf.errormsg))
            # put STACK_NAME if updated
            if ssm_paramstore.conf.get(ENV_STACK) != configItem.get(ENV_STACK):
                ver = ssm_paramstore.conf.put(ENV_STACK, configItem.get(ENV_STACK))
                if ver == 0:
                    print("{} update error: {}".format(ENV_STACK,ssm_paramstore.conf.errormsg))
            # put TAG_NAME if updated
            if ssm_paramstore.conf.get(ENV_TAG_NAME) != configItem.get(ENV_TAG_NAME):
                ver = ssm_paramstore.conf.put(ENV_TAG_NAME, configItem.get(ENV_TAG_NAME))
                if ver == 0:
                    print("{} update error: {}".format(ENV_TAG_NAME,ssm_paramstore.conf.errormsg))
            # put TRACE if updated
            if ssm_paramstore.conf.get(ENV_TRACE) != configItem.get(ENV_TRACE):
                ver = ssm_paramstore.conf.put(ENV_TRACE, configItem.get(ENV_TRACE))
                if ver == 0:
                    print("{} update error: {}".format(ENV_TRACE,ssm_paramstore.conf.errormsg))
            # put USER_AGENT if updated
            if ssm_paramstore.conf.get(ENV_USER_AGENT) != configItem.get(ENV_USER_AGENT):
                ver = ssm_paramstore.conf.put(ENV_USER_AGENT, configItem.get(ENV_USER_AGENT))
                if ver == 0:
                    print("{} update error: {}".format(ENV_USER_AGENT,ssm_paramstore.conf.errormsg))
            # put BOTO_RETRY if updated
            if ssm_paramstore.conf.get(ENV_BOTO_RETRIES) != configItem.get(ENV_BOTO_RETRIES):
                ver = ssm_paramstore.conf.put(ENV_BOTO_RETRIES, configItem.get(ENV_BOTO_RETRIES))
                if ver == 0:
                    print("{} update error: {}".format(ENV_BOTO_RETRIES,ssm_paramstore.conf.errormsg))
            # put BOTO_RETRY_LOGGING if updated
            if ssm_paramstore.conf.get(ENV_BOTO_RETRY_LOGGING) != configItem.get(ENV_BOTO_RETRY_LOGGING):
                ver = ssm_paramstore.conf.put(ENV_BOTO_RETRY_LOGGING, configItem.get(ENV_BOTO_RETRY_LOGGING))
                if ver == 0:
                    print("{} update error: {}".format(ENV_BOTO_RETRY_LOGGING,ssm_paramstore.conf.errormsg))
            # put METRICS_URL if updated
            if ssm_paramstore.conf.get(ENV_METRICS_URL) != configItem.get(ENV_METRICS_URL):
                ver = ssm_paramstore.conf.put(ENV_METRICS_URL, configItem.get(ENV_METRICS_URL))
                if ver == 0:
                    print("{} update error: {}".format(ENV_METRICS_URL,ssm_paramstore.conf.errormsg))
            # put SOLUTION_ID if updated
            if ssm_paramstore.conf.get(ENV_SOLUTION_ID) != configItem.get(ENV_SOLUTION_ID):
                ver = ssm_paramstore.conf.put(ENV_SOLUTION_ID, configItem.get(ENV_SOLUTION_ID))
                if ver == 0:
                    print("{} update error: {}".format(ENV_SOLUTION_ID,ssm_paramstore.conf.errormsg))
            # put SEND_METRICS if updated
            if ssm_paramstore.conf.get(ENV_SEND_METRICS) != configItem.get(ENV_SEND_METRICS):
                ver = ssm_paramstore.conf.put(ENV_SEND_METRICS, configItem.get(ENV_SEND_METRICS))
                if ver == 0:
                    print("{} update error: {}".format(ENV_SEND_METRICS,ssm_paramstore.conf.errormsg))
            # put LOG_GROUP if updated
            if ssm_paramstore.conf.get(ENV_LOG_GROUP) != configItem.get(ENV_LOG_GROUP):
                ver = ssm_paramstore.conf.put(ENV_LOG_GROUP, configItem.get(ENV_LOG_GROUP))
                if ver == 0:
                    print("{} update error: {}".format(ENV_LOG_GROUP,ssm_paramstore.conf.errormsg))
            # put ISSUES_TOPIC_ARN if updated
            if ssm_paramstore.conf.get(ENV_ISSUES_TOPIC_ARN) != configItem.get(ENV_ISSUES_TOPIC_ARN):
                ver = ssm_paramstore.conf.put(ENV_ISSUES_TOPIC_ARN, configItem.get(ENV_ISSUES_TOPIC_ARN))
                if ver == 0:
                    print("{} update error: {}".format(ENV_ISSUES_TOPIC_ARN,ssm_paramstore.conf.errormsg))

        except Exception as ex:
            print("Put config error: {}".format(str(ex)))
            traceback.print_exc()
            result["Reason"] = str(ex)
            result["Status"] = 'FAILED'

    send_response(event, result)


# Send the response to cloudformation
def send_response(event, result):
        # Build the PUT request and the response data
        resp = json.dumps(result)

        headers = {
            'content-type': '',
            'content-length': str(len(resp))
        }

        # PUT request to cloudformation
        try:
            response = requests.put(event.get("ResponseURL"), data=json.dumps(result), headers=headers)
            response.raise_for_status()
            print("Status code: {}".format(response.status_code))
            print("Status message: {}".format(response.text))
            return True
        except Exception as exc:
            print("Failed executing HTTP request to respond to CloudFormation stack {}".format(event.get("StackId")))
            print("Error code is {}".format(str(exc)))
            print("Url is {}".format(event.get("ResponseURL")))
            print("Response data is {}".format(resp))
            return False
